import os
import shutil
import tkinter as tk
from tkinter import filedialog

def choose_folder():
    folder_path = filedialog.askdirectory()
    entry_folder.delete(0, tk.END)
    entry_folder.insert(0, folder_path)

def copy_tokyo_zip():
    # Get the game folder path from the text entry
    game_folder = entry_folder.get()

    # Check if the game folder exists
    if not os.path.exists(game_folder):
        result_label.config(text=f"Game folder '{game_folder}' does not exist.")
        return

    # Path to the 'levels' folder in the game folder
    levels_folder = os.path.join(game_folder, 'content', 'levels')

    # Check if the 'levels' folder exists
    if not os.path.exists(levels_folder):
        result_label.config(text=f"'Levels' folder does not exist in the game folder '{game_folder}'.")
        return

    # Path to the tokyo.zip file
    tokyo_zip_path = os.path.join(os.getcwd(), 'data', 'tokyo.zip')

    # Check if the tokyo.zip file exists
    if not os.path.exists(tokyo_zip_path):
        result_label.config(text="File 'tokyo.zip' does not exist in the 'data' folder.")
        return

    try:
        # Copy the tokyo.zip file to the levels folder
        shutil.copy(tokyo_zip_path, levels_folder)
        result_label.config(text="File 'tokyo.zip' has been copied to the 'levels' folder in the game.")
    except Exception as e:
        result_label.config(text=f"An error occurred while copying the file: {e}")

# Create the main window
root = tk.Tk()
root.title("Adding map to BeamMP script")

# Text entry for entering the game folder path
entry_folder = tk.Entry(root, width=50)
entry_folder.grid(row=0, column=0, padx=10, pady=10)

# Button for choosing the folder
button_browse = tk.Button(root, text="Browse Folder", command=choose_folder)
button_browse.grid(row=0, column=1, padx=5, pady=10)

# Button for copying the file
button_copy = tk.Button(root, text="Copy File", command=copy_tokyo_zip)
button_copy.grid(row=1, column=0, columnspan=2, pady=10)

# Result label
result_label = tk.Label(root, text="")
result_label.grid(row=2, column=0, columnspan=2)

# Run the main loop
root.mainloop()
